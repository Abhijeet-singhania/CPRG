/**
 * Simulates SSO login using Azure AD. In a real application, this function
 * would initiate the Azure AD authentication flow (e.g., redirect to Azure AD
 * login page, handle the callback, and obtain user tokens).
 * For now, it returns hardcoded user data.
 *
 * @returns {Promise<{success: boolean, user?: object, message?: string}>} A promise that resolves with the login result.
 */
export async function ssoLogin() {
  try {
    // In a real scenario, you would integrate with Azure AD SDK (e.g., MSAL.js)
    // and perform the login redirect or popup.
    // Example (conceptual):
    // const msalInstance = new Msal.UserAgentApplication(msalConfig);
    // await msalInstance.loginPopup(loginRequest);
    // const account = msalInstance.getAccount();

    // For demonstration, return hardcoded user data after a delay
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = { name: "Abhijeet", avatar: "/avatar.png" };
        resolve({ success: true, user });
      }, 1000);
    });
  } catch (err) {
    console.error("SSO failed:", err);
    return { success: false, message: "SSO failed" };
  }
}
  