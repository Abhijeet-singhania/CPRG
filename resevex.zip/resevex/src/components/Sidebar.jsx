import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, FileText, FolderKanban, Settings, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

const routes = [
  { name: "Dashboard", path: "/", icon: <LayoutDashboard size={20} /> },
  {
    name: "Projects",
    icon: <FolderKanban size={20} />,
    subRoutes: [
      { name: "Crane", path: "/crane" },
      { name: "Scaffolding", path: "/scaffolding" },
      { name: "Rope Access", path: "/ropeaccess" },
    ],
  },
  { name: "Reports", path: "/reports", icon: <FileText size={20} /> },
  { name: "Settings", path: "/settings", icon: <Settings size={20} /> },
];

export default function Sidebar({ isSidebarOpen, setSidebarOpen }) {
  return (
    <aside className={`fixed top-16 left-0 h-[calc(100%-4rem)] bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-20'} p-4 flex flex-col`}>
      <nav className="flex flex-col gap-2 flex-grow">
        <button onClick={() => setSidebarOpen(prev => !prev)} className="flex items-center justify-between w-full gap-2 px-3 py-2.5 rounded-md text-left text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
          <div className="flex items-center gap-3 mt-3">
            {isSidebarOpen ? <ChevronLeft size={24} /> : <ChevronRight size={24} />}
            {isSidebarOpen && <span className="font-medium">Navigation</span>}
          </div>
        </button>
        <div className="border-b border-black-200 dark:border-black-700 my-2"></div>
        {routes.map((r) => (
          <NavItem key={r.name} item={r} isSidebarOpen={isSidebarOpen} />
        ))}
      </nav>
      <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
        <p className={`text-xs text-gray-500 dark:text-gray-400 ${!isSidebarOpen && 'hidden'}`}>© 2024 Construction Inc.</p>
      </div>
    </aside>
  );
}

function NavItem({ item, isSidebarOpen }) {
  const { pathname } = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  if (item.subRoutes) {
    const isActive = item.subRoutes.some(sr => pathname.startsWith(sr.path));
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center justify-between w-full gap-2 px-3 py-2.5 rounded-md text-left ${isActive ? "bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"}`}>
          <div className="flex items-center gap-3">
            {item.icon}
            {isSidebarOpen && <span className="font-medium">{item.name}</span>}
          </div>
          {isSidebarOpen && <ChevronDown size={18} className={`transition-transform ${isOpen ? "rotate-180" : ""}`} />}
        </button>
        {isOpen && isSidebarOpen && (
          <div className="pl-8 pt-2 flex flex-col gap-1">
            {item.subRoutes.map((sr) => (
              <Link
                key={sr.name}
                to={sr.path}
                className={`block px-3 py-1.5 rounded-md text-sm ${pathname === sr.path ? "text-blue-500 font-semibold" : "text-gray-500 dark:text-gray-400 hover:text-blue-500"}`}>
                {sr.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <Link
      to={item.path}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-md ${pathname === item.path ? "bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"}`}>
      {item.icon}
      {isSidebarOpen && <span className="font-medium">{item.name}</span>}
    </Link>
  );
}



