import { useTheme } from "../context/ThemeContext";
import { SunIcon, MoonIcon } from "lucide-react";

export default function ThemeToggle() {
  const { dark, setDark } = useTheme();

  return (
    <button onClick={() => setDark(!dark)} className="text-xl p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
      {dark ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
    </button>
  );
}
