import ThemeToggle from "./ThemeToggle.jsx";
import { User, LogOut, Users, Tractor, GitBranch, Layers } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

export default function Header({ user }) {
  const navigate = useNavigate();
  const location = useLocation();

  const misIcons = [
    { name: "Manpower", route: "/", icon: <Users size={24} />, color: "text-sky-500", hover: "hover:text-sky-600 hover:shadow-sky-500/50" },
    { name: "Crane", route: "/crane", icon: <Tractor size={24} />, color: "text-amber-500", hover: "hover:text-amber-600 hover:shadow-amber-500/50" },
    { name: "Rope Access", route: "/ropeaccess", icon: <GitBranch size={24} />, color: "text-emerald-500", hover: "hover:text-emerald-600 hover:shadow-emerald-500/50" },
    { name: "Scaffolding", route: "/scaffolding", icon: <Layers size={24} />, color: "text-violet-500", hover: "hover:text-violet-600 hover:shadow-violet-500/50" },
  ];

  return (
    <header className="fixed top-0 left-0 w-full z-10 flex items-center justify-between px-6 py-3 border-b bg-white dark:bg-gray-800">
      <div className="flex items-center gap-4">
        <img src="/logo.png" className="w-10 h-10" />
        <div className="text-xl font-semibold text-gray-800 dark:text-gray-200">Resource exchange portal</div>
      </div>

      <div className="flex items-center gap-6 mx-auto">
        {misIcons.map((item) => (
          <button
            key={item.name}
            onClick={() => navigate(item.route)}
            className={`flex flex-col items-center text-xs ${item.color} dark:text-gray-300 ${item.hover} dark:hover:text-blue-400 transition-all duration-300 shadow-lg rounded-lg p-2
              ${location.pathname === item.route ? "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300" : ""}`}
          >
            {item.icon}
            <span className="mt-1">{item.name}</span>
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <ThemeToggle />
        <div className="flex items-center gap-3">
          <img src={user.avatar} className="w-10 h-10 rounded-full border-2 border-blue-500" />
          <div>
            <div className="font-semibold text-gray-800 dark:text-gray-200">{user.name}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Project Manager</div>
          </div>
        </div>
        <button onClick={() => location.reload()} className="flex gap-2 items-center text-red-500 hover:text-red-600 px-3 py-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-800 hover:shadow-red-500/50 shadow-lg transition-all duration-300">
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
