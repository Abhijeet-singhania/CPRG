import { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ssoLogin } from "./auth.js";
import Sidebar from "./components/Sidebar.jsx";
import Header from "./components/Header.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Crane from "./pages/Crane.jsx";
import Scaffolding from "./pages/Scaffolding.jsx";
import RopeAccess from "./pages/RopeAccess.jsx";

function App() {
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    ssoLogin().then(res => {
      if (res.success) setUser(res.user);
      else setError(res.message);
    });
  }, []);

  if (error) return <div className="text-center mt-10 text-red-500 text-lg">{error}</div>;

  return (
    <Router>
      <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
        {user && <Sidebar isSidebarOpen={isSidebarOpen} setSidebarOpen={setSidebarOpen} />}
        <div className={`flex flex-col flex-1 transition-all duration-300 ${user ? (isSidebarOpen ? "ml-64" : "ml-20") : "ml-0"}`}>
          {user && <Header user={user} />}
          <main className="p-6 flex-grow pt-16 overflow-y-auto">
            <Routes>
              <Route path="/login" element={<div className="text-center mt-10 text-lg">Please log in to access the portal.</div>} />
              <Route
                path="/"
                element={
                  <ProtectedRoute user={user}>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/crane"
                element={
                  <ProtectedRoute user={user}>
                    <Crane />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/scaffolding"
                element={
                  <ProtectedRoute user={user}>
                    <Scaffolding />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/ropeaccess"
                element={
                  <ProtectedRoute user={user}>
                    <RopeAccess />
                  </ProtectedRoute>
                }
              />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;
