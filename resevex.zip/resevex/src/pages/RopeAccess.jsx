export default function RopeAccess() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Rope Access</h1>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Rope Access Teams</h2>
        <p className="text-gray-600 dark:text-gray-300">3 teams are currently deployed.</p>
      </div>
    </div>
  );
}
  