import { 
  users, 
  projects, 
  manpower, 
  equipment, 
  inspections, 
  activities,
  type User, 
  type InsertUser,
  type Project,
  type InsertProject,
  type Manpower,
  type InsertManpower,
  type Equipment,
  type InsertEquipment,
  type Inspection,
  type InsertInspection,
  type Activity,
  type InsertActivity
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getAllProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<Project>): Promise<Project | undefined>;

  // Manpower operations
  getManpower(id: number): Promise<Manpower | undefined>;
  getAllManpower(): Promise<Manpower[]>;
  getManpowerByProject(projectId: number): Promise<Manpower[]>;
  createManpower(manpower: InsertManpower): Promise<Manpower>;
  updateManpower(id: number, manpower: Partial<Manpower>): Promise<Manpower | undefined>;

  // Equipment operations
  getEquipment(id: number): Promise<Equipment | undefined>;
  getAllEquipment(): Promise<Equipment[]>;
  getEquipmentByType(type: string): Promise<Equipment[]>;
  getEquipmentByProject(projectId: number): Promise<Equipment[]>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: number, equipment: Partial<Equipment>): Promise<Equipment | undefined>;

  // Inspection operations
  getInspection(id: number): Promise<Inspection | undefined>;
  getAllInspections(): Promise<Inspection[]>;
  getInspectionsByEquipment(equipmentId: number): Promise<Inspection[]>;
  createInspection(inspection: InsertInspection): Promise<Inspection>;

  // Activity operations
  getActivity(id: number): Promise<Activity | undefined>;
  getAllActivities(): Promise<Activity[]>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private manpower: Map<number, Manpower>;
  private equipment: Map<number, Equipment>;
  private inspections: Map<number, Inspection>;
  private activities: Map<number, Activity>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentManpowerId: number;
  private currentEquipmentId: number;
  private currentInspectionId: number;
  private currentActivityId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.manpower = new Map();
    this.equipment = new Map();
    this.inspections = new Map();
    this.activities = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentManpowerId = 1;
    this.currentEquipmentId = 1;
    this.currentInspectionId = 1;
    this.currentActivityId = 1;

    // Initialize with some sample data for demonstration
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample projects
    const sampleProjects: InsertProject[] = [
      {
        name: "Construction Site Alpha",
        description: "Main construction project for commercial building",
        status: "active",
        managerId: 1
      },
      {
        name: "Infrastructure Project Beta",
        description: "Road and utilities infrastructure development",
        status: "active",
        managerId: 1
      },
      {
        name: "Residential Complex Gamma",
        description: "Multi-story residential building complex",
        status: "completed",
        managerId: 1
      }
    ];

    // Create sample equipment
    const sampleEquipment: InsertEquipment[] = [
      {
        type: "crane",
        name: "Tower Crane TC-1",
        model: "Liebherr 280 EC-H",
        status: "available",
        projectId: 1
      },
      {
        type: "crane",
        name: "Mobile Crane MC-1",
        model: "Tadano GR-1000XL",
        status: "in_use",
        projectId: 1
      },
      {
        type: "rope",
        name: "Steel Wire Rope SWR-1",
        model: "6x19 IWRC",
        status: "available",
        projectId: 1
      },
      {
        type: "rope",
        name: "Synthetic Rope SR-1",
        model: "Dyneema SK78",
        status: "maintenance",
        projectId: 2
      },
      {
        type: "scaffolding",
        name: "Modular Scaffolding MS-1",
        model: "Layher Allround",
        status: "in_use",
        projectId: 1
      },
      {
        type: "scaffolding",
        name: "Frame Scaffolding FS-1",
        model: "Safway Standard",
        status: "available",
        projectId: 2
      }
    ];

    // Create sample manpower
    const sampleManpower: InsertManpower[] = [
      {
        userId: 1,
        projectId: 1,
        position: "Site Supervisor",
        status: "active"
      },
      {
        userId: 1,
        projectId: 1,
        position: "Crane Operator",
        status: "active"
      },
      {
        userId: 1,
        projectId: 2,
        position: "Safety Inspector",
        status: "active"
      },
      {
        userId: 1,
        projectId: 1,
        position: "Construction Worker",
        status: "inactive"
      }
    ];

    // Initialize projects
    sampleProjects.forEach(project => {
      const id = this.currentProjectId++;
      const newProject: Project = {
        ...project,
        id,
        createdAt: new Date()
      };
      this.projects.set(id, newProject);
    });

    // Initialize equipment
    sampleEquipment.forEach(equip => {
      const id = this.currentEquipmentId++;
      const newEquipment: Equipment = {
        ...equip,
        id,
        createdAt: new Date(),
        lastMaintenance: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
        nextMaintenance: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      };
      this.equipment.set(id, newEquipment);
    });

    // Initialize manpower
    sampleManpower.forEach(mp => {
      const id = this.currentManpowerId++;
      const newManpower: Manpower = {
        ...mp,
        id,
        assignedAt: new Date()
      };
      this.manpower.set(id, newManpower);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = {
      ...insertProject,
      id,
      createdAt: new Date()
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateData: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject = { ...project, ...updateData };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  // Manpower operations
  async getManpower(id: number): Promise<Manpower | undefined> {
    return this.manpower.get(id);
  }

  async getAllManpower(): Promise<Manpower[]> {
    return Array.from(this.manpower.values());
  }

  async getManpowerByProject(projectId: number): Promise<Manpower[]> {
    return Array.from(this.manpower.values()).filter(mp => mp.projectId === projectId);
  }

  async createManpower(insertManpower: InsertManpower): Promise<Manpower> {
    const id = this.currentManpowerId++;
    const manpower: Manpower = {
      ...insertManpower,
      id,
      assignedAt: new Date()
    };
    this.manpower.set(id, manpower);
    return manpower;
  }

  async updateManpower(id: number, updateData: Partial<Manpower>): Promise<Manpower | undefined> {
    const manpower = this.manpower.get(id);
    if (!manpower) return undefined;

    const updatedManpower = { ...manpower, ...updateData };
    this.manpower.set(id, updatedManpower);
    return updatedManpower;
  }

  // Equipment operations
  async getEquipment(id: number): Promise<Equipment | undefined> {
    return this.equipment.get(id);
  }

  async getAllEquipment(): Promise<Equipment[]> {
    return Array.from(this.equipment.values());
  }

  async getEquipmentByType(type: string): Promise<Equipment[]> {
    return Array.from(this.equipment.values()).filter(eq => eq.type === type);
  }

  async getEquipmentByProject(projectId: number): Promise<Equipment[]> {
    return Array.from(this.equipment.values()).filter(eq => eq.projectId === projectId);
  }

  async createEquipment(insertEquipment: InsertEquipment): Promise<Equipment> {
    const id = this.currentEquipmentId++;
    const equipment: Equipment = {
      ...insertEquipment,
      id,
      createdAt: new Date()
    };
    this.equipment.set(id, equipment);
    return equipment;
  }

  async updateEquipment(id: number, updateData: Partial<Equipment>): Promise<Equipment | undefined> {
    const equipment = this.equipment.get(id);
    if (!equipment) return undefined;

    const updatedEquipment = { ...equipment, ...updateData };
    this.equipment.set(id, updatedEquipment);
    return updatedEquipment;
  }

  // Inspection operations
  async getInspection(id: number): Promise<Inspection | undefined> {
    return this.inspections.get(id);
  }

  async getAllInspections(): Promise<Inspection[]> {
    return Array.from(this.inspections.values());
  }

  async getInspectionsByEquipment(equipmentId: number): Promise<Inspection[]> {
    return Array.from(this.inspections.values()).filter(insp => insp.equipmentId === equipmentId);
  }

  async createInspection(insertInspection: InsertInspection): Promise<Inspection> {
    const id = this.currentInspectionId++;
    const inspection: Inspection = {
      ...insertInspection,
      id,
      inspectedAt: new Date()
    };
    this.inspections.set(id, inspection);
    return inspection;
  }

  // Activity operations
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async getAllActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values());
  }

  async getRecentActivities(limit: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
    return activities;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = {
      ...insertActivity,
      id,
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
