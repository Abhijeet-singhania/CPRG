import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertActivitySchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/auth/sso", async (req, res) => {
    try {
      // Simulate SSO authentication - replace with actual SSO implementation
      const mockUser = {
        username: "john.anderson",
        email: "john.anderson@construction.com",
        name: "John Anderson",
        role: "Project Manager",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
        isActive: true,
      };
      
      const user = await storage.createUser(mockUser);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "SSO authentication failed" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      // In a real app, get user from session/token
      const users = await storage.getAllUsers();
      const user = users[0]; // Mock current user
      
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    // Clear session/token
    res.json({ message: "Logged out successfully" });
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      const manpower = await storage.getAllManpower();
      const equipment = await storage.getAllEquipment();
      
      res.json({
        activeProjects: projects.filter(p => p.status === 'active').length,
        totalWorkers: manpower.length,
        equipmentUnits: equipment.length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get dashboard stats" });
    }
  });

  app.get("/api/dashboard/project-stats", async (req, res) => {
    try {
      // Mock project statistics
      res.json({
        completedProjects: 85,
        resourceUtilization: 72,
        safetyCompliance: 98,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get project stats" });
    }
  });

  // Activities
  app.get("/api/activities/recent", async (req, res) => {
    try {
      const activities = await storage.getRecentActivities(10);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recent activities" });
    }
  });

  app.post("/api/activities", async (req, res) => {
    try {
      const activity = insertActivitySchema.parse(req.body);
      const newActivity = await storage.createActivity(activity);
      res.json(newActivity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create activity" });
      }
    }
  });

  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to get projects" });
    }
  });

  // Manpower
  app.get("/api/manpower", async (req, res) => {
    try {
      const manpower = await storage.getAllManpower();
      res.json(manpower);
    } catch (error) {
      res.status(500).json({ message: "Failed to get manpower" });
    }
  });

  // Equipment
  app.get("/api/equipment/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const equipment = await storage.getEquipmentByType(type as any);
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to get equipment" });
    }
  });

  app.get("/api/equipment", async (req, res) => {
    try {
      const equipment = await storage.getAllEquipment();
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to get equipment" });
    }
  });

  // Inspections
  app.get("/api/inspections", async (req, res) => {
    try {
      const inspections = await storage.getAllInspections();
      res.json(inspections);
    } catch (error) {
      res.status(500).json({ message: "Failed to get inspections" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
