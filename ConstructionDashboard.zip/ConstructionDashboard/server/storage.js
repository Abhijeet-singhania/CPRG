import { 
  users, 
  projects, 
  manpower, 
  equipment, 
  inspections, 
  activities
} from "../shared/schema.js";

export class MemStorage {
  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.manpower = new Map();
    this.equipment = new Map();
    this.inspections = new Map();
    this.activities = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentManpowerId = 1;
    this.currentEquipmentId = 1;
    this.currentInspectionId = 1;
    this.currentActivityId = 1;

    // Initialize with some sample data for demonstration
    this.initializeSampleData();
  }

  initializeSampleData() {
    // Create sample projects
    const sampleProjects = [
      {
        name: "Construction Site Alpha",
        description: "Main construction project for commercial building",
        status: "active",
        managerId: 1
      },
      {
        name: "Infrastructure Project Beta",
        description: "Road and utilities infrastructure development",
        status: "active",
        managerId: 1
      },
      {
        name: "Residential Complex Gamma",
        description: "Multi-story residential building complex",
        status: "completed",
        managerId: 1
      }
    ];

    // Create sample equipment
    const sampleEquipment = [
      {
        type: "crane",
        name: "Tower Crane TC-1",
        model: "Liebherr 280 EC-H",
        status: "available",
        projectId: 1
      },
      {
        type: "crane",
        name: "Mobile Crane MC-1",
        model: "Tadano GR-1000XL",
        status: "in_use",
        projectId: 1
      },
      {
        type: "rope",
        name: "Steel Wire Rope SWR-1",
        model: "6x19 IWRC",
        status: "available",
        projectId: 1
      },
      {
        type: "rope",
        name: "Synthetic Rope SR-1",
        model: "Dyneema SK78",
        status: "maintenance",
        projectId: 2
      },
      {
        type: "scaffolding",
        name: "Modular Scaffolding MS-1",
        model: "Layher Allround",
        status: "in_use",
        projectId: 1
      },
      {
        type: "scaffolding",
        name: "Frame Scaffolding FS-1",
        model: "Safway Standard",
        status: "available",
        projectId: 2
      }
    ];

    // Create sample manpower
    const sampleManpower = [
      {
        userId: 1,
        projectId: 1,
        position: "Site Supervisor",
        status: "active"
      },
      {
        userId: 1,
        projectId: 1,
        position: "Crane Operator",
        status: "active"
      },
      {
        userId: 1,
        projectId: 2,
        position: "Safety Inspector",
        status: "active"
      },
      {
        userId: 1,
        projectId: 1,
        position: "Construction Worker",
        status: "inactive"
      }
    ];

    // Initialize projects
    sampleProjects.forEach(project => {
      const id = this.currentProjectId++;
      const newProject = {
        ...project,
        id,
        createdAt: new Date()
      };
      this.projects.set(id, newProject);
    });

    // Initialize equipment
    sampleEquipment.forEach(equip => {
      const id = this.currentEquipmentId++;
      const newEquipment = {
        ...equip,
        id,
        createdAt: new Date(),
        lastMaintenance: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
        nextMaintenance: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      };
      this.equipment.set(id, newEquipment);
    });

    // Initialize manpower
    sampleManpower.forEach(mp => {
      const id = this.currentManpowerId++;
      const newManpower = {
        ...mp,
        id,
        assignedAt: new Date()
      };
      this.manpower.set(id, newManpower);
    });
  }

  // User operations
  async getUser(id) {
    return this.users.get(id);
  }

  async getUserByUsername(username) {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser) {
    const id = this.currentUserId++;
    const user = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers() {
    return Array.from(this.users.values());
  }

  // Project operations
  async getProject(id) {
    return this.projects.get(id);
  }

  async getAllProjects() {
    return Array.from(this.projects.values());
  }

  async createProject(insertProject) {
    const id = this.currentProjectId++;
    const project = {
      ...insertProject,
      id,
      createdAt: new Date()
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id, updateData) {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject = { ...project, ...updateData };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  // Manpower operations
  async getManpower(id) {
    return this.manpower.get(id);
  }

  async getAllManpower() {
    return Array.from(this.manpower.values());
  }

  async getManpowerByProject(projectId) {
    return Array.from(this.manpower.values()).filter(mp => mp.projectId === projectId);
  }

  async createManpower(insertManpower) {
    const id = this.currentManpowerId++;
    const manpower = {
      ...insertManpower,
      id,
      assignedAt: new Date()
    };
    this.manpower.set(id, manpower);
    return manpower;
  }

  async updateManpower(id, updateData) {
    const manpower = this.manpower.get(id);
    if (!manpower) return undefined;

    const updatedManpower = { ...manpower, ...updateData };
    this.manpower.set(id, updatedManpower);
    return updatedManpower;
  }

  // Equipment operations
  async getEquipment(id) {
    return this.equipment.get(id);
  }

  async getAllEquipment() {
    return Array.from(this.equipment.values());
  }

  async getEquipmentByType(type) {
    return Array.from(this.equipment.values()).filter(eq => eq.type === type);
  }

  async getEquipmentByProject(projectId) {
    return Array.from(this.equipment.values()).filter(eq => eq.projectId === projectId);
  }

  async createEquipment(insertEquipment) {
    const id = this.currentEquipmentId++;
    const equipment = {
      ...insertEquipment,
      id,
      createdAt: new Date()
    };
    this.equipment.set(id, equipment);
    return equipment;
  }

  async updateEquipment(id, updateData) {
    const equipment = this.equipment.get(id);
    if (!equipment) return undefined;

    const updatedEquipment = { ...equipment, ...updateData };
    this.equipment.set(id, updatedEquipment);
    return updatedEquipment;
  }

  // Inspection operations
  async getInspection(id) {
    return this.inspections.get(id);
  }

  async getAllInspections() {
    return Array.from(this.inspections.values());
  }

  async getInspectionsByEquipment(equipmentId) {
    return Array.from(this.inspections.values()).filter(insp => insp.equipmentId === equipmentId);
  }

  async createInspection(insertInspection) {
    const id = this.currentInspectionId++;
    const inspection = {
      ...insertInspection,
      id,
      inspectedAt: new Date()
    };
    this.inspections.set(id, inspection);
    return inspection;
  }

  // Activity operations
  async getActivity(id) {
    return this.activities.get(id);
  }

  async getAllActivities() {
    return Array.from(this.activities.values());
  }

  async getRecentActivities(limit) {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
    return activities;
  }

  async createActivity(insertActivity) {
    const id = this.currentActivityId++;
    const activity = {
      ...insertActivity,
      id,
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();