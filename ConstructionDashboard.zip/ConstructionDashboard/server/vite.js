export function log(message, source = "express") {
  const timestamp = new Date().toLocaleTimeString("en-US", { hour12: false });
  console.log(`${timestamp} [${source}] ${message}`);
}

export async function setupVite(app, server) {
  const vite = await (
    await import("vite")
  ).createServer({
    server: { middlewareMode: true },
    appType: "spa",
  });

  app.use(vite.ssrFixStacktrace);
  app.use(vite.middlewares);
  return { vite };
}

export async function serveStatic(app) {
  const sirv = (await import("sirv")).default;
  
  app.use(
    sirv("dist/public", {
      gzip: true,
      brotli: true,
    }),
  );
}