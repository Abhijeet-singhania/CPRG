import { Layout } from '@/components/layout/Layout.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, UserPlus, Calendar, TrendingUp } from 'lucide-react';

export default function ManpowerMIS() {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Manpower MIS</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Manage workers, attendance, and productivity tracking
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Workers</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">45</p>
                </div>
                <Users className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">New Hires</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">8</p>
                </div>
                <UserPlus className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Attendance Rate</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">96%</p>
                </div>
                <Calendar className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Productivity</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">87%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-600 dark:text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Manpower Management</CardTitle>
            <CardDescription>Comprehensive worker and productivity management system</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-400">
              Manpower MIS module features will be implemented here including worker registration, 
              attendance tracking, performance monitoring, and productivity analytics.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}