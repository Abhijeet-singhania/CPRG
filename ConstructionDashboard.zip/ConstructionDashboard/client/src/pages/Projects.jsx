import { Layout } from '@/components/layout/Layout.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FolderOpen, Plus, Calendar, Users } from 'lucide-react';

export default function Projects() {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Projects</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Manage and track all construction projects
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5" />
              Project Management
            </CardTitle>
            <CardDescription>
              Comprehensive project tracking and management system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-400">
              Projects module features will be implemented here including project creation, 
              tracking, team assignment, timeline management, and progress monitoring.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}