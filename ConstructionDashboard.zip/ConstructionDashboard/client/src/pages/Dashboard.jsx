import { Layout } from '@/components/layout/Layout.jsx';
import { WelcomeSection } from '@/components/dashboard/WelcomeSection.jsx';
import { MISQuickAccess } from '@/components/dashboard/MISQuickAccess.jsx';
import { RecentActivity } from '@/components/dashboard/RecentActivity.jsx';

export default function Dashboard() {
  return (
    <Layout>
      <div className="space-y-6">
        <WelcomeSection />
        <MISQuickAccess />
        <RecentActivity />
      </div>
    </Layout>
  );
}