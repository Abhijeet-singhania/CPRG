import { Layout } from '@/components/layout/Layout.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { HardHat, Building, Shield, CheckCircle } from 'lucide-react';

export default function ScaffoldingMIS() {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Scaffolding MIS</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Manage scaffolding setup, safety compliance, and inspections
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Structures</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">16</p>
                </div>
                <Building className="w-8 h-8 text-orange-600 dark:text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Safety Compliance</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">95%</p>
                </div>
                <Shield className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Inspected Today</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">12</p>
                </div>
                <CheckCircle className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Workers Protected</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">45</p>
                </div>
                <HardHat className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Scaffolding Safety Management</CardTitle>
            <CardDescription>Comprehensive scaffolding setup and safety compliance system</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-400">
              Scaffolding MIS module features will be implemented here including structure management, 
              safety inspections, compliance tracking, and worker protection monitoring.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}