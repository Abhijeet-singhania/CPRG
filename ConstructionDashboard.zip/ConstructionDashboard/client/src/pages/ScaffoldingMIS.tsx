import { useQuery } from '@tanstack/react-query';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Grid3X3, Plus, Shield, AlertTriangle } from 'lucide-react';
import { Equipment } from '@shared/schema';

export default function ScaffoldingMIS() {
  const { data: scaffolding, isLoading } = useQuery<Equipment[]>({
    queryKey: ['/api/equipment', 'scaffolding'],
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="animate-pulse h-8 bg-gray-200 dark:bg-gray-700 rounded w-48"></div>
            <div className="animate-pulse h-10 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
              <Grid3X3 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Scaffolding MIS
            </h1>
          </div>
          <Button className="bg-purple-600 hover:bg-purple-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Scaffolding
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Units</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {scaffolding?.filter(s => s.type === 'scaffolding').length || 0}
                  </p>
                </div>
                <Grid3X3 className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Safe & Ready</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {scaffolding?.filter(s => s.type === 'scaffolding' && s.status === 'available').length || 0}
                  </p>
                </div>
                <Shield className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">In Use</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {scaffolding?.filter(s => s.type === 'scaffolding' && s.status === 'in_use').length || 0}
                  </p>
                </div>
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 dark:text-blue-400 font-bold">⚙</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Safety Issues</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {scaffolding?.filter(s => s.type === 'scaffolding' && s.status === 'maintenance').length || 0}
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Scaffolding Table */}
        <Card>
          <CardHeader>
            <CardTitle>Scaffolding Setup & Safety Monitoring</CardTitle>
          </CardHeader>
          <CardContent>
            {scaffolding && scaffolding.filter(s => s.type === 'scaffolding').length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Unit ID
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Name
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Type
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Safety Status
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Next Inspection
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {scaffolding.filter(s => s.type === 'scaffolding').map((scaffold) => (
                      <tr key={scaffold.id} className="border-b border-gray-100 dark:border-gray-800">
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          #{scaffold.id}
                        </td>
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          {scaffold.name}
                        </td>
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          {scaffold.model || 'Standard'}
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            scaffold.status === 'available' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                              : scaffold.status === 'in_use'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                          }`}>
                            {scaffold.status === 'available' ? 'Safe' : 
                             scaffold.status === 'in_use' ? 'In Use' : 'Needs Inspection'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-gray-600 dark:text-gray-400">
                          {scaffold.nextMaintenance ? new Date(scaffold.nextMaintenance).toLocaleDateString() : 'Not scheduled'}
                        </td>
                        <td className="py-3 px-4">
                          <Button variant="outline" size="sm">
                            Monitor
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Grid3X3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">No scaffolding units registered yet</p>
                <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Unit
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
