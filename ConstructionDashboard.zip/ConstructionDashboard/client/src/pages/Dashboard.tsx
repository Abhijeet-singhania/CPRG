import { Layout } from '@/components/layout/Layout';
import { WelcomeSection } from '@/components/dashboard/WelcomeSection';
import { MISQuickAccess } from '@/components/dashboard/MISQuickAccess';
import { RecentActivity } from '@/components/dashboard/RecentActivity';

export default function Dashboard() {
  return (
    <Layout>
      <div className="fade-in">
        <WelcomeSection />
        <MISQuickAccess />
        <RecentActivity />
      </div>
    </Layout>
  );
}
