import { useQuery } from '@tanstack/react-query';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link as LinkIcon, Plus, CheckCircle, AlertTriangle } from 'lucide-react';
import { Equipment } from '@shared/schema';

export default function RopeMIS() {
  const { data: ropes, isLoading } = useQuery<Equipment[]>({
    queryKey: ['/api/equipment', 'rope'],
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="animate-pulse h-8 bg-gray-200 dark:bg-gray-700 rounded w-48"></div>
            <div className="animate-pulse h-10 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-yellow-100 dark:bg-yellow-900 rounded-lg flex items-center justify-center">
              <LinkIcon className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Rope MIS
            </h1>
          </div>
          <Button className="bg-yellow-600 hover:bg-yellow-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Rope
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Ropes</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {ropes?.filter(r => r.type === 'rope').length || 0}
                  </p>
                </div>
                <LinkIcon className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Safe to Use</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {ropes?.filter(r => r.type === 'rope' && r.status === 'available').length || 0}
                  </p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">In Use</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {ropes?.filter(r => r.type === 'rope' && r.status === 'in_use').length || 0}
                  </p>
                </div>
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 dark:text-blue-400 font-bold">⚙</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Needs Inspection</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {ropes?.filter(r => r.type === 'rope' && r.status === 'maintenance').length || 0}
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Rope Safety Table */}
        <Card>
          <CardHeader>
            <CardTitle>Rope Safety & Inspection Management</CardTitle>
          </CardHeader>
          <CardContent>
            {ropes && ropes.filter(r => r.type === 'rope').length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Rope ID
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Name
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Type
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Safety Status
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Next Inspection
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900 dark:text-white">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {ropes.filter(r => r.type === 'rope').map((rope) => (
                      <tr key={rope.id} className="border-b border-gray-100 dark:border-gray-800">
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          #{rope.id}
                        </td>
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          {rope.name}
                        </td>
                        <td className="py-3 px-4 text-gray-900 dark:text-white">
                          {rope.model || 'Standard'}
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            rope.status === 'available' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                              : rope.status === 'in_use'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                          }`}>
                            {rope.status === 'available' ? 'Safe' : 
                             rope.status === 'in_use' ? 'In Use' : 'Needs Inspection'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-gray-600 dark:text-gray-400">
                          {rope.nextMaintenance ? new Date(rope.nextMaintenance).toLocaleDateString() : 'Not scheduled'}
                        </td>
                        <td className="py-3 px-4">
                          <Button variant="outline" size="sm">
                            Inspect
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <LinkIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">No ropes registered yet</p>
                <Button className="mt-4 bg-yellow-600 hover:bg-yellow-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Rope
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
