import { Layout } from '@/components/layout/Layout.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Construction, Wrench, Calendar, AlertTriangle } from 'lucide-react';

export default function CraneMIS() {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Crane MIS</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Monitor crane operations, maintenance, and safety protocols
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Cranes</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">8</p>
                </div>
                <Construction className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Under Maintenance</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">2</p>
                </div>
                <Wrench className="w-8 h-8 text-orange-600 dark:text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Next Inspection</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">3d</p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Safety Alerts</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">1</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Crane Operations Management</CardTitle>
            <CardDescription>Comprehensive crane monitoring and maintenance system</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-400">
              Crane MIS module features will be implemented here including crane tracking, 
              maintenance scheduling, safety inspections, and operational analytics.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}