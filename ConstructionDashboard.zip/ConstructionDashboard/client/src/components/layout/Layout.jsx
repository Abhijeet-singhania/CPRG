import { Header } from './Header.jsx';
import { Sidebar } from './Sidebar.jsx';

export function Layout({ children, className }) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className={`flex-1 p-6 ${className || ''}`}>
          {children}
        </main>
      </div>
    </div>
  );
}