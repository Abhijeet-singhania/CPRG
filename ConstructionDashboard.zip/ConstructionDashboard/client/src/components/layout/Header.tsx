import { useState } from 'react';
import { useAuth } from '@/contexts/AuthProvider';
import { useTheme } from '@/contexts/ThemeProvider';
import { Button } from '@/components/ui/button';
import { Link, useLocation } from 'wouter';
import { 
  Users, 
  Truck, 
  Link as LinkIcon, 
  Grid3X3, 
  Sun, 
  Moon,
  User,
  LogOut,
  Building
} from 'lucide-react';

export function Header() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location, setLocation] = useLocation();

  const misItems = [
    { 
      name: 'Manpower', 
      icon: Users, 
      path: '/manpower', 
      color: 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 hover:bg-blue-200 dark:hover:bg-blue-800' 
    },
    { 
      name: 'Crane', 
      icon: Truck, 
      path: '/crane', 
      color: 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-800' 
    },
    { 
      name: 'Rope', 
      icon: LinkIcon, 
      path: '/rope', 
      color: 'bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-200 dark:hover:bg-yellow-800' 
    },
    { 
      name: 'Scaffolding', 
      icon: Grid3X3, 
      path: '/scaffolding', 
      color: 'bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 hover:bg-purple-200 dark:hover:bg-purple-800' 
    },
  ];

  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 fixed w-full top-0 z-50 h-16">
      <div className="flex items-center justify-between h-full px-4">
        
        {/* Left Section: Logo and Portal Name */}
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Building className="w-5 h-5 text-white" />
          </div>
          
          <div className="hidden md:block">
            <h1 className="text-lg font-semibold text-gray-900 dark:text-white">
              Construction Management Portal
            </h1>
          </div>
          
          <div className="md:hidden">
            <h1 className="text-sm font-semibold text-gray-900 dark:text-white">
              CMS Portal
            </h1>
          </div>
        </div>
        
        {/* Center Section: MIS Icons */}
        <div className="hidden lg:flex items-center space-x-6">
          <div className="flex items-center space-x-4">
            {misItems.map((item) => (
              <Link key={item.name} href={item.path}>
                <button className="group flex flex-col items-center space-y-1 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors duration-200 ${item.color}`}>
                    <item.icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                    {item.name}
                  </span>
                </button>
              </Link>
            ))}
          </div>
        </div>
        
        {/* Right Section: User Profile */}
        <div className="flex items-center space-x-4">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            {theme === 'dark' ? (
              <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            ) : (
              <Moon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            )}
          </Button>
          
          {/* User Profile Section */}
          {user && (
            <div className="flex items-center space-x-3">
              <img 
                src={user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150"} 
                alt="User Profile" 
                className="w-8 h-8 rounded-full border-2 border-gray-200 dark:border-gray-600"
              />
              
              <div className="hidden md:block">
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {user.name}
                </span>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {user.role}
                </p>
              </div>
              
              {/* Profile Actions */}
              <div className="flex items-center space-x-2">
                <Link href="/profile">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
                  >
                    <User className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                  </Button>
                </Link>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
                >
                  <LogOut className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
