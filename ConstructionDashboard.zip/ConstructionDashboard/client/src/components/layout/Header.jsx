import { Link } from 'wouter';
import { useAuth } from '@/contexts/AuthProvider.jsx';
import { useTheme } from '@/contexts/ThemeProvider.jsx';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Building2, Users, Construction, Cable, HardHat, Sun, Moon, User, LogOut, Settings } from 'lucide-react';

export function Header() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo - Extreme Left */}
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
            </div>
          </Link>
        </div>

        {/* Website Name - Center */}
        <div className="flex-1 text-center">
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">
            Construction Management Portal
          </h1>
        </div>

        {/* MIS Icons and User Profile - Right */}
        <div className="flex items-center gap-4">
          {/* 4 MIS Icons */}
          <div className="flex items-center gap-2">
            <Link href="/manpower">
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center gap-1 h-auto p-2 hover:bg-blue-50 dark:hover:bg-blue-900/20"
              >
                <Users className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <Badge variant="secondary" className="text-xs">Manpower</Badge>
              </Button>
            </Link>
            
            <Link href="/crane">
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center gap-1 h-auto p-2 hover:bg-green-50 dark:hover:bg-green-900/20"
              >
                <Construction className="w-5 h-5 text-green-600 dark:text-green-400" />
                <Badge variant="secondary" className="text-xs">Crane</Badge>
              </Button>
            </Link>
            
            <Link href="/rope">
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center gap-1 h-auto p-2 hover:bg-purple-50 dark:hover:bg-purple-900/20"
              >
                <Cable className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <Badge variant="secondary" className="text-xs">Rope</Badge>
              </Button>
            </Link>
            
            <Link href="/scaffolding">
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center gap-1 h-auto p-2 hover:bg-orange-50 dark:hover:bg-orange-900/20"
              >
                <HardHat className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                <Badge variant="secondary" className="text-xs">Scaffolding</Badge>
              </Button>
            </Link>
          </div>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            {theme === 'light' ? (
              <Moon className="w-5 h-5" />
            ) : (
              <Sun className="w-5 h-5" />
            )}
          </Button>

          {/* User Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.avatar} alt={user?.name} />
                  <AvatarFallback>
                    {user?.name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="text-left hidden md:block">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {user?.name}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    {user?.role}
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem asChild>
                <Link href="/profile" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Profile
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings" className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Settings
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <LogOut className="w-4 h-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}