import { useQuery } from '@tanstack/react-query';

interface DashboardStats {
  activeProjects: number;
  totalWorkers: number;
  equipmentUnits: number;
}

export function WelcomeSection() {
  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  return (
    <div className="mb-8">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white">
        <h2 className="text-3xl font-bold mb-2">Welcome to Construction Portal</h2>
        <p className="text-blue-100 mb-4">
          Manage your construction projects efficiently with our comprehensive MIS system
        </p>
        <div className="flex flex-wrap gap-4">
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 flex-1 min-w-[200px]">
            <h3 className="font-semibold mb-1">Active Projects</h3>
            <p className="text-2xl font-bold">
              {stats?.activeProjects ?? 0}
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 flex-1 min-w-[200px]">
            <h3 className="font-semibold mb-1">Total Workers</h3>
            <p className="text-2xl font-bold">
              {stats?.totalWorkers ?? 0}
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 flex-1 min-w-[200px]">
            <h3 className="font-semibold mb-1">Equipment Units</h3>
            <p className="text-2xl font-bold">
              {stats?.equipmentUnits ?? 0}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
