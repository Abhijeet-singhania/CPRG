import { Link } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Construction, Cable, HardHat, ArrowRight, Activity, AlertTriangle } from 'lucide-react';

export function MISQuickAccess() {
  const misModules = [
    {
      title: 'Manpower MIS',
      description: 'Manage workers, attendance, and productivity',
      href: '/manpower',
      icon: Users,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20',
      borderColor: 'border-blue-200 dark:border-blue-800',
      stats: {
        active: 45,
        total: 52,
        status: 'Active'
      }
    },
    {
      title: 'Crane MIS',
      description: 'Monitor crane operations and maintenance',
      href: '/crane',
      icon: Construction,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      borderColor: 'border-green-200 dark:border-green-800',
      stats: {
        active: 8,
        total: 12,
        status: 'Operational'
      }
    },
    {
      title: 'Rope MIS',
      description: 'Track rope safety and inspections',
      href: '/rope',
      icon: Cable,
      color: 'text-purple-600 dark:text-purple-400',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20',
      borderColor: 'border-purple-200 dark:border-purple-800',
      stats: {
        active: 24,
        total: 30,
        status: 'Inspected'
      }
    },
    {
      title: 'Scaffolding MIS',
      description: 'Manage scaffolding setup and safety',
      href: '/scaffolding',
      icon: HardHat,
      color: 'text-orange-600 dark:text-orange-400',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20',
      borderColor: 'border-orange-200 dark:border-orange-800',
      stats: {
        active: 16,
        total: 20,
        status: 'Compliant'
      }
    },
  ];

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          MIS Quick Access
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Access your management information systems
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {misModules.map((module, index) => {
          const Icon = module.icon;
          
          return (
            <Card 
              key={index} 
              className={`hover:shadow-lg transition-all duration-200 border-2 ${module.borderColor} ${module.bgColor}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className={`w-10 h-10 rounded-lg ${module.bgColor} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${module.color}`} />
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {module.stats.status}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{module.title}</CardTitle>
                <CardDescription className="text-sm">
                  {module.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Active/Total</span>
                    <span className="font-medium">
                      {module.stats.active}/{module.stats.total}
                    </span>
                  </div>
                  
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${module.color.replace('text-', 'bg-')}`}
                      style={{ 
                        width: `${(module.stats.active / module.stats.total) * 100}%` 
                      }}
                    ></div>
                  </div>
                  
                  <Button asChild className="w-full mt-4" variant="outline">
                    <Link href={module.href}>
                      Access {module.title.split(' ')[0]}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Quick Actions
            </CardTitle>
            <CardDescription>
              Common tasks and shortcuts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button asChild variant="outline" className="h-auto p-4">
                <Link href="/projects">
                  <div className="text-center">
                    <div className="text-sm font-medium">View All Projects</div>
                    <div className="text-xs text-gray-500 mt-1">Manage active projects</div>
                  </div>
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="h-auto p-4">
                <Link href="/reports">
                  <div className="text-center">
                    <div className="text-sm font-medium">Generate Reports</div>
                    <div className="text-xs text-gray-500 mt-1">Analytics and insights</div>
                  </div>
                </Link>
              </Button>
              
              <Button variant="outline" className="h-auto p-4 text-orange-600 border-orange-200 hover:bg-orange-50">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 text-sm font-medium">
                    <AlertTriangle className="w-4 h-4" />
                    Safety Alerts
                  </div>
                  <div className="text-xs text-gray-500 mt-1">2 pending reviews</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}