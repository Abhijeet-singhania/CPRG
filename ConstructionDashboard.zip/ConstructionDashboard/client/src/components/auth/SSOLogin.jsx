import { useState } from 'react';
import { useAuth } from '@/contexts/AuthProvider.jsx';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building2, Shield, Users, Wrench } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeProvider.jsx';

export function SSOLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const { initiateSSO } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const handleSSOLogin = async () => {
    setIsLoading(true);
    try {
      await initiateSSO();
    } catch (error) {
      console.error('SSO login failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm"
        >
          {theme === 'light' ? '🌙' : '☀️'}
        </Button>
      </div>

      <div className="w-full max-w-md">
        <Card className="shadow-xl bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">
                Construction Portal
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Management Information System
              </CardDescription>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-3">
              <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-1" />
                <Badge variant="secondary" className="text-xs">Manpower</Badge>
              </div>
              <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <Wrench className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto mb-1" />
                <Badge variant="secondary" className="text-xs">Equipment</Badge>
              </div>
              <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <Shield className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-1" />
                <Badge variant="secondary" className="text-xs">Safety</Badge>
              </div>
              <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <Building2 className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto mb-1" />
                <Badge variant="secondary" className="text-xs">Projects</Badge>
              </div>
            </div>

            <Button 
              onClick={handleSSOLogin} 
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              size="lg"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Authenticating...
                </div>
              ) : (
                'Sign In with SSO'
              )}
            </Button>

            <div className="text-center">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Secure access for construction management teams
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}