import { useState } from 'react';
import { useAuth } from '@/contexts/AuthProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Building, LogIn, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function SSOLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const { initiateSSO } = useAuth();
  const { toast } = useToast();

  const handleSSO = async () => {
    setIsLoading(true);
    try {
      await initiateSSO();
      toast({
        title: "Authentication successful",
        description: "Welcome to the Construction Management Portal!",
      });
    } catch (error) {
      toast({
        title: "Authentication failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestAccess = () => {
    toast({
      title: "Guest access",
      description: "Guest access is currently disabled. Please use SSO authentication.",
      variant: "destructive",
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-md w-full mx-4">
        <Card className="bg-white dark:bg-gray-800 shadow-2xl border border-gray-200 dark:border-gray-700">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              {/* Company Logo */}
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-600 rounded-full flex items-center justify-center">
                <Building className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                Construction Portal
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                Management Information System
              </p>
            </div>
            
            <div className="space-y-6">
              <Button
                onClick={handleSSO}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-4 py-3 text-base font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                ) : (
                  <LogIn className="w-5 h-5 mr-2" />
                )}
                {isLoading ? 'Authenticating...' : 'Sign in with SSO'}
              </Button>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300 dark:border-gray-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">
                    Or continue with
                  </span>
                </div>
              </div>
              
              <Button
                onClick={handleGuestAccess}
                variant="outline"
                className="w-full flex items-center justify-center px-4 py-3 text-base font-medium rounded-lg border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
              >
                <User className="w-5 h-5 mr-2" />
                Guest Access
              </Button>
            </div>
            
            <div className="mt-8 text-center">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                By signing in, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
