import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Truck, Link as LinkIcon, Grid3X3 } from 'lucide-react';

export function MISQuickAccess() {
  const misItems = [
    {
      title: 'Manpower MIS',
      description: 'Workforce management and attendance tracking',
      icon: Users,
      path: '/manpower',
      color: 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400',
      buttonColor: 'bg-blue-600 hover:bg-blue-700',
      growth: '+12%',
    },
    {
      title: 'Crane MIS',
      description: 'Crane operations and maintenance tracking',
      icon: Truck,
      path: '/crane',
      color: 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400',
      buttonColor: 'bg-green-600 hover:bg-green-700',
      growth: '+8%',
    },
    {
      title: 'Rope MIS',
      description: 'Rope safety and inspection management',
      icon: LinkIcon,
      path: '/rope',
      color: 'bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-400',
      buttonColor: 'bg-yellow-600 hover:bg-yellow-700',
      growth: '+5%',
    },
    {
      title: 'Scaffolding MIS',
      description: 'Scaffolding setup and safety monitoring',
      icon: Grid3X3,
      path: '/scaffolding',
      color: 'bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400',
      buttonColor: 'bg-purple-600 hover:bg-purple-700',
      growth: '+3%',
    },
  ];

  return (
    <div className="mb-8">
      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        MIS Quick Access
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {misItems.map((item) => (
          <Card key={item.title} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${item.color}`}>
                  <item.icon className="w-6 h-6" />
                </div>
                <span className="text-sm text-green-600 dark:text-green-400 font-medium">
                  {item.growth}
                </span>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {item.title}
              </h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                {item.description}
              </p>
              <Link href={item.path}>
                <Button className={`w-full font-medium py-2 px-4 rounded-lg text-white transition-colors duration-200 ${item.buttonColor}`}>
                  Open MIS
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
