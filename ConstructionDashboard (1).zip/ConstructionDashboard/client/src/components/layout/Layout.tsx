import { ReactNode } from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: ReactNode;
  className?: string;
}

export function Layout({ children, className }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <Sidebar />
      <main className={cn(
        "transition-all duration-300 pt-16 ml-64",
        className
      )}>
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
