import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { 
  Building, 
  ChevronLeft, 
  LayoutDashboard, 
  FolderOpen, 
  FileText, 
  Settings,
  HelpCircle 
} from 'lucide-react';

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [location] = useLocation();

  const navigationItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/', active: location === '/' },
    { name: 'Projects', icon: FolderOpen, path: '/projects', active: location === '/projects' },
    { name: 'Reports', icon: FileText, path: '/reports', active: location === '/reports' },
    { name: 'Settings', icon: Settings, path: '/settings', active: location === '/settings' },
  ];

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <aside className={cn(
      "fixed left-0 top-16 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 z-40",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Building className="w-5 h-5 text-white" />
            </div>
            {!isCollapsed && (
              <span className="font-semibold text-gray-900 dark:text-white">
                Portal Navigation
              </span>
            )}
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleSidebar}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <ChevronLeft className={cn(
              "w-4 h-4 text-gray-600 dark:text-gray-400 transition-transform duration-200",
              isCollapsed && "rotate-180"
            )} />
          </Button>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 p-4 space-y-2">
          <div className="space-y-2">
            {navigationItems.map((item) => (
              <Link key={item.name} href={item.path}>
                <button className={cn(
                  "flex items-center space-x-3 p-3 rounded-lg transition-colors duration-200 w-full text-left",
                  item.active 
                    ? "bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-400" 
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                )}>
                  <item.icon className="w-5 h-5 flex-shrink-0" />
                  {!isCollapsed && <span>{item.name}</span>}
                </button>
              </Link>
            ))}
          </div>
        </nav>
        
        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
              <HelpCircle className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            </div>
            {!isCollapsed && (
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Help & Support
              </span>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}
