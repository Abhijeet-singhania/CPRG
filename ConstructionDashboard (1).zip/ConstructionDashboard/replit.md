# Construction Management Portal

## Overview

This is a full-stack construction management portal built with React, TypeScript, Express.js, and PostgreSQL. The application provides a comprehensive Management Information System (MIS) for construction companies to manage manpower, equipment (cranes, ropes, scaffolding), projects, and safety inspections.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful APIs with structured error handling
- **Development**: Hot reload with Vite middleware integration

### Database Architecture
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Migrations**: Drizzle Kit for schema management
- **Schema**: Shared schema definitions between client and server

## Key Components

### Authentication System
- **SSO Integration**: Mock SSO authentication system (ready for real implementation)
- **Session Management**: Cookie-based session handling
- **Context Provider**: React context for auth state management
- **Protected Routes**: Route-level authentication guards

### MIS Modules
1. **Manpower MIS**: Worker management, attendance, and productivity tracking
2. **Crane MIS**: Crane operations, maintenance, and safety monitoring
3. **Rope MIS**: Rope safety inspections and lifecycle management
4. **Scaffolding MIS**: Scaffolding setup and safety compliance

### Core Features
- **Dashboard**: Real-time project statistics and activity monitoring
- **Project Management**: Project creation, tracking, and team assignment
- **Equipment Management**: Multi-type equipment tracking with maintenance schedules
- **Inspection System**: Safety inspections with pass/fail results
- **Reporting**: Analytics and report generation
- **Theme System**: Dark/light mode with system preference detection

## Data Flow

1. **Client Requests**: React components use TanStack Query for data fetching
2. **API Layer**: Express.js handles HTTP requests with structured error handling
3. **Business Logic**: Server-side logic processes requests and validates data
4. **Database Operations**: Drizzle ORM handles database interactions
5. **Response**: JSON responses with consistent error handling
6. **State Management**: TanStack Query caches and synchronizes server state

## External Dependencies

### Frontend Dependencies
- **UI Library**: Radix UI primitives for accessible components
- **Icons**: Lucide React for consistent iconography
- **Form Handling**: React Hook Form with Zod validation
- **Date Utilities**: date-fns for date manipulation
- **Carousel**: Embla Carousel for image/content sliders

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connectivity
- **Validation**: Zod for runtime type checking and validation
- **Session Store**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution in development

### Build and Development Tools
- **Build**: esbuild for server bundling, Vite for client bundling
- **Development**: Replit-specific plugins for development environment
- **Linting**: TypeScript compiler for type checking

## Deployment Strategy

### Development Environment
- **Server**: Node.js with tsx for TypeScript execution
- **Client**: Vite dev server with HMR (Hot Module Replacement)
- **Database**: PostgreSQL with Drizzle migrations
- **Environment**: Replit-optimized with specific plugins and configurations

### Production Build
- **Server**: Compiled with esbuild to ESM format
- **Client**: Optimized Vite build with code splitting
- **Assets**: Static files served from dist/public
- **Database**: Drizzle migrations applied via npm scripts

### Configuration Management
- **Environment Variables**: DATABASE_URL for database connection
- **TypeScript**: Strict mode enabled with path mapping
- **Bundling**: Separate client and server build processes
- **Static Assets**: Proper asset resolution and serving

The architecture emphasizes type safety, modern development practices, and scalability while maintaining simplicity for construction industry users.